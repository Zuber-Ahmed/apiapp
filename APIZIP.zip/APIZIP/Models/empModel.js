const mongoose = require("mongoose");

const empModel = mongoose.model("emp", {

//     userId: { type: Number },
//   id: { type: Number },
// //   title: { type: String },
// //   completed:{type:Boolean}
});

module.exports = empModel;
